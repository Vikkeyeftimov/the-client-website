> Fork deze leertaak en ga aan de slag, de instructie vind je in: [docs/INSTRUCTIONS.md](docs/INSTRUCTIONS.md)

## Licentie

This project is licensed under the terms of the [MIT license](./LICENSE).
