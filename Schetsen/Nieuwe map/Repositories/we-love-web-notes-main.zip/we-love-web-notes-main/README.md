> _Fork_ deze leertaak en ga aan de slag. De instructie vind je in: [docs/INSTRUCTIONS.md](https://github.com/fdnd-task/we-love-web-notes/blob/main/docs/INSTRUCTIONS.md)

# We ♥ Web Notes

Een plek voor het bijhouden van aantekeningen van de We ♥ Web presentaties en workshops. 


## Licentie

This project is licensed under the terms of the [MIT license](./LICENSE).
