
# We ♥ Web Notes

Een plek voor het bijhouden van aantekeningen van de We ♥ Web presentaties en workshops. 

## Context

Deze leertaak hoort bij semester 1 - The Static Web. 

## Doel van deze opdracht

Leren op de hoogte te blijven van internationale ontwikkelingen die van belang zijn voor een frontender.

## Werkwijze

Het frontend vakgebied verandert voortdurend. 
Een goede frontender blijft op de hoogte van internationale ontwikkelingen en trends op het gebied van technologie, digitaal- en interactie ontwerp. 
Hierom worden Bij FDND elke sprint gastsprekers uitgenodigd tijdens de We ♥ Web sessies. 

Houd in de Wiki je aantekeningen bij van de We Love Web presentaties. 

## Criteria

Deze leertaak hoort bij het gedragscriterium van _Lerend Vermogen_:

Semester 1
- Benoemt behandelde internationale ontwikkelingen in het vakgebied.

          



