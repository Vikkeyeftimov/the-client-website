> _Fork_ deze deeltaak en ga aan de slag. Onderstaande outline ga je gedurende deze taak in jouw eigen GitHub omgeving uitwerken. 
De instructie vind je in: [docs/INSTRUCTIONS.md](docs/INSTRUCTIONS.md)

# Layout in CSS

Een oefening in document layout met CSS.

## Licentie

This project is licensed under the terms of the [MIT license](./LICENSE).
