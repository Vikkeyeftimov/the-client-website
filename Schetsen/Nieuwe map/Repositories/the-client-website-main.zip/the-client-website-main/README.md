> _Fork_ deze leertaak en ga aan de slag. Onderstaande outline ga je gedurende deze taak in jouw eigen GitHub omgeving uitwerken. De instructie vind je, zoals altijd, in: [docs/INSTRUCTIONS.md](docs/INSTRUCTIONS.md)

# Titel
B-RAIN ze nieuwste design
Mijn project is dat ik een website maak voor de bedrijf b-Rain, bedoeling is dat ik mensen nog meer geintresseerd moet maken over de idee van b-Rain. b-Rainis een bedrijf die streeft naar een beter wateromgeving daar bedoel ik mee dat ze willen dat je slimmer ben met het water die je opspaart in waterton. 

## Inhoudsopgave

  * [Beschrijving](#beschrijving)
  * [Kenmerken](#kenmerken)
  * [Bronnen](#bronnen)
  * [Licentie](#licentie)

## Beschrijving
Mijn project/website probeer ik op spatwater website te laten lijken maar niet teveel dat je denk dat het hetzelde website is. Bijvoorbeeld bij spatwater website kan je een stad in achtergrond zien en dat wou ik ook gaan toepassen bij mijn website en dat was wel redelijk goed gelukt maar ik wil design van de stad nog wel aanpassen. We kregen ook een style van kleuren die we soort van moesten gaan gebruiken en dat ik heb tot nu toe nog niet helemaal goed toegepast want ik mis nog kleuren maar overtijd ga ik dat zeker aanpassen. ik heb een ig toegevoegd aan mijn website om te laten lijken alsof het aan regenen in de stad maar het is een gif op infinte loop. Ik heb nog niet heel veel maar dat gaat zeker veranderen en dan geef ik mijn readme ook meteen updates daarbij. 
Ik heb ook een navbar die nog geen echte functie heeft maar ik ga link in die navbar doen dat je naar andere delen van website kan gaan als je daar behoefte aan hebt. je kan nu nog niet veel met mijn website maar ik heb wel meeste content van b-RAIN er in gezet dus als je daar intressen in hebt kan je zeker even kijken.
<!-- Voeg een mooie poster visual toe 📸 -->
<!-- Voeg een link toe naar Github Pages 🌐-->

## Kenmerken
in css is flexbox erg belangrijk en z-index want dat zorgt ervoor dat alles eruit ziet hoe ik het wil maar ik moet zeker daar nog dingen aan toepassen. html zijn het zeker de foto's erg belangrijk en javasrcipt heb ik nog niet gedaan. 



## Licentie

This project is licensed under the terms of the [MIT license](./LICENSE).
