> _Fork_ deze deeltaak en ga aan de slag. 
De instructie vind je in: [docs/INSTRUCTIONS.md](docs/INSTRUCTIONS.md)

# Naam deeltaak

## Licentie

This project is licensed under the terms of the [MIT license](./LICENSE).
